require('dotenv').config();

const { pool } = require('./db/rds-config');
const { dynamoDB, GetCommand, UpdateCommand } = require('./db/aws-config');

const TABLE_TASK    = process.env.DYNAMODB_TASK_TABLE || 'Tasks';
const FULL_TASK_TAB = `${process.env.DB_SCHEMA_TASK}.${process.env.DB_TASK}`;

module.exports.handler = async (event) => {
  console.log("Received event:", JSON.stringify(event, null, 2));

  // 1. Extract taskId from path
  const taskId = event?.pathParameters?.id;
  if (!taskId) {
    console.error("Missing taskId in pathParameters.");
    return {
      statusCode: 400,
      body: JSON.stringify({
        error: 'Missing taskId in path. Make sure your route is /tasks/{id} and that "id" is passed in pathParameters.'
      })
    };
  }

  try {
    // 2. Check if task exists in DynamoDB
    const getResp = await dynamoDB.send(new GetCommand({
      TableName: TABLE_TASK,
      Key: { taskId }
    }));

    if (!getResp.Item) {
      return {
        statusCode: 404,
        body: JSON.stringify({ error: 'Task not found in DynamoDB.' })
      };
    }

    // 3. Fetch task from Postgres
    const { rows } = await pool.query(
      `SELECT 
         task_id    AS "taskId",
         title,
         description,
         status,
         attachments,
         priority
       FROM ${FULL_TASK_TAB}
       WHERE task_id = $1`,
      [taskId]
    );

    if (rows.length === 0) {
      return {
        statusCode: 404,
        body: JSON.stringify({ error: 'Task not found in RDS.' })
      };
    }
    const pgTask = rows[0];

    // 4. Update metadata in DynamoDB
    const ts = new Date().toISOString();
    const updateResp = await dynamoDB.send(new UpdateCommand({
      TableName: TABLE_TASK,
      Key: { taskId },
      UpdateExpression: `
        SET 
          view_count   = if_not_exists(view_count, :zero) + :inc,
          last_viewed  = :ts,
          updatedAt    = :ts,
          activity_log = list_append(if_not_exists(activity_log, :empty), :entry)
      `,
      ExpressionAttributeValues: {
        ':zero':  0,
        ':inc':   1,
        ':ts':    ts,
        ':empty': [],
        ':entry': [`Viewed at ${ts}`]
      },
      ReturnValues: 'ALL_NEW'
    }));

    const ddbTask = updateResp.Attributes;

    // 5. Return combined result
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        ...pgTask,
        metadata: ddbTask
      })
    };

  } catch (error) {
    console.error('getTask error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Internal server error', details: error.message })
    };
  }
};
