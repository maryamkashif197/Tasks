import boto3
import os
import json

print("Lambda is running in region:", os.environ.get('AWS_REGION'))
ses = boto3.client('ses', region_name='eu-north-1')
print("SES client is using region:", ses.meta.region_name)

def lambda_handler(event, context):
    identity = event["identity"]
    typ = event.get("type", "email").lower()
    
    print("Verifying identity:", identity)
    print("Type:", typ)

    try:
        response = ses.get_identity_verification_attributes(Identities=[identity])
        attrs = response['VerificationAttributes']
        if identity in attrs and attrs[identity]['VerificationStatus'] == 'Success':
            print(f"✅ {identity} is already verified.")
            return {
                "statusCode": 200,
                "body": json.dumps({"message": f"{identity} is already verified."})
            }

        # If not verified, trigger verification
        if typ == "email":
            print(f"Sending email verification to: {identity}")
            resp = ses.verify_email_identity(EmailAddress=identity)
        else:
            print(f"Sending domain verification for: {identity}")
            resp = ses.verify_domain_identity(Domain=identity)

        return {
            "statusCode": 200,
            "body": json.dumps({"message": f"Verification initiated for {identity}", "details": resp})
        }

    except Exception as e:
        print(f"❌ Error verifying identity: {str(e)}")
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }
