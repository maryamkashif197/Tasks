// lambda/tasks/deleteTask.js
require('dotenv').config();
const { pool }            = require('./db/rds-config');
const { dynamoDB, snsClient } = require('./db/aws-config');
const { GetCommand, DeleteCommand } = require('@aws-sdk/lib-dynamodb');
const { PublishCommand }  = require('@aws-sdk/client-sns');
const AWS = require("aws-sdk");


const sns                = new AWS.SNS();

const DDB_TABLE     = process.env.DYNAMO_TABLE || 'Tasks';
const RDS_SCHEMA    = process.env.DB_SCHEMA_TASK;    // e.g. "tasks_data"
const RDS_TABLE     = process.env.DB_TASK;           // e.g. "tasks"
const FULL_RDS      = `${RDS_SCHEMA}.${RDS_TABLE}`;
const SNS_TOPIC_ARN = process.env.SNS_TOPIC_ARN;

module.exports.handler = async (event) => {
  const taskId = event.pathParameters?.id;
  if (!taskId) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: 'Missing taskId in path' })
    };
  }

  try {
    // ── 1) Look up cognito_sub in Postgres ─────────────────────────
    const { rows: [ pgTask ] = [] } = await pool.query(
      `SELECT cognito_sub FROM ${FULL_RDS} WHERE task_id = $1`,
      [ taskId ]
    );
    if (!pgTask) {
      return { statusCode: 404, body: JSON.stringify({ error: 'Task not found in RDS' }) };
    }
    const cognitoSub = pgTask.cognito_sub;
    console.log('cognitoSub:', cognitoSub);

    // ── 2) Fetch user email (optional) ─────────────────────────────
    const { rows: [ user ] = [] } = await pool.query(
      `SELECT email FROM users_data.users WHERE cognito_sub = $1`,
      [ cognitoSub ]
    );
    const email = user?.email || null;
    console.log('email:', email);

    // ── 3) Ensure it exists in DynamoDB ───────────────────────────
    const getResp = await dynamoDB.send(new GetCommand({
      TableName: DDB_TABLE,
      Key:       { taskId }
    }));
    if (!getResp.Item) {
      return { statusCode: 404, body: JSON.stringify({ error: 'Task not found in DynamoDB' }) };
    }
    const now = new Date().toISOString();
    await sns.publish({
      TopicArn: SNS_TOPIC_ARN,
      Message: JSON.stringify({
        userId: cognitoSub,
        email,
        taskId,
        action: 'deleted'
      })
    }).promise();

    // ── 4) Delete from DynamoDB ───────────────────────────────────
    await dynamoDB.send(new DeleteCommand({
      TableName: DDB_TABLE,
      Key:       { taskId }
    }));

    // ── 5) Delete from Postgres RDS ───────────────────────────────
    await pool.query(
      `DELETE FROM ${FULL_RDS} WHERE task_id = $1`,
      [ taskId ]
    );

    // ── 6) Publish to SNS so your SQS subscriber sees it ──────────
    

    // ── 7) Done ───────────────────────────────────────────────────
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'DELETE,OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type'
      },
      body: JSON.stringify({ message: 'Task deleted successfully' })
    };

  } catch (err) {
    console.error('deleteTask error:', err);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message })
    };
  }
};
