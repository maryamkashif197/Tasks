// lambda/tasks/createTask.js

const AWS          = require('aws-sdk')
const { pool }     = require('./db/rds-config')
const { dynamoDB, PutCommand, uuidv4 } = require('./db/aws-config')

const s3   = new AWS.S3()
const sns  = new AWS.SNS()

const BUCKET         = process.env.S3_BUCKET           // e.g. "task-manager-file-storage"
const TABLE_TASK     = process.env.DB_TASK             // e.g. "tasks"
const SCHEMA_TASK    = process.env.DB_SCHEMA_TASK      // e.g. "tasks_data"
const FULL_TASK_TAB  = `${SCHEMA_TASK}.${TABLE_TASK}`
const SNS_TOPIC_ARN  = process.env.SNS_TOPIC_ARN
const DDB_TASK_TABLE = process.env.DYNAMODB_TASK_TABLE

const CORS = {
  'Access-Control-Allow-Origin':  '*',
  'Access-Control-Allow-Methods': 'OPTIONS,POST',
  'Access-Control-Allow-Headers': 'Content-Type'
}

exports.handler = async event => {
  // 1) handle CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode:200, headers:CORS, body:'' }
  }

  try {
    // 2) parse JSON body
    const {
      title,
      description = null,
      dueDate     = null,
      priority    = 'Medium',
      userId,
      attachments = []
    } = JSON.parse(event.body)

    if (!title || !userId) {
      throw new Error('Missing required fields: title or userId')
    }

    // 3) upload each to S3
    const uploadedUrls = await Promise.all(
      attachments.map(async file => {
        const key = `tasks/${uuidv4()}_${file.filename}`
        const buffer = Buffer.from(file.data, 'base64')
        await s3.putObject({
          Bucket:      BUCKET,
          Key:         key,
          Body:        buffer,
          ContentType: file.fileType,
          // ACL:         'public-read'
        }).promise()
        return `https://${BUCKET}.s3.amazonaws.com/${key}`
      })
    )

    // 4) insert into Postgres
    const taskId = uuidv4()
    await pool.query(
      `
      INSERT INTO ${FULL_TASK_TAB}
        (task_id,title,description,due_date,attachments,priority,cognito_sub)
      VALUES ($1,$2,$3,$4,$5,$6,$7)
      `,
      [
        taskId,
        title,
        description,
        dueDate,
        uploadedUrls,  // TEXT[] in Postgres
        priority,
        userId
      ]
    )

    // 5) lookup email, write Dynamo metadata + SNS notify (same as before)...
    const { rows } = await pool.query(
      'SELECT email FROM users_data.users WHERE cognito_sub = $1',
      [userId]
    )
    const email = rows[0]?.email || null

    await dynamoDB.send(new PutCommand({
      TableName: DDB_TASK_TABLE,
      Item: {
        taskId,
        activity_log: [
          `Created at ${new Date().toISOString()}`,
          `Updated at ${new Date().toISOString()}`
        ],
        view_count:  0,
        last_viewed: null,
        tags:        []
      }
    }))

    await sns.publish({
      TopicArn: SNS_TOPIC_ARN,
      Message: JSON.stringify({
        userId: userId,
        email,                  // <-- pass email here
        taskId: taskId,
        action: "created"
      }) }).promise();

    // 6) respond
    return {
      statusCode: 201,
      headers:    { ...CORS, 'Content-Type':'application/json' },
      body:       JSON.stringify({
        taskId, title, description, dueDate,
        priority, attachments: uploadedUrls
      })
    }

  } catch (err) {
    console.error('createTask error:', err)
    return {
      statusCode: 500,
      headers:    CORS,
      body:       JSON.stringify({ error: err.message })
    }
  }
}
