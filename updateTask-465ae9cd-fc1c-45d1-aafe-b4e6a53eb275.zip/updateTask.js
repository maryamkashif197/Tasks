// lambda/tasks/updateTask.js
require('dotenv').config();
const AWS     = require('aws-sdk');
const parser  = require('lambda-multipart-parser');
const { pool }              = require('./db/rds-config');
const { dynamoDB, snsClient } = require('./db/aws-config');
const { GetCommand, UpdateCommand } = require('@aws-sdk/lib-dynamodb');
const { PublishCommand }    = require('@aws-sdk/client-sns');

const s3   = new AWS.S3();
const sns  = new AWS.SNS();

const BUCKET         = process.env.S3_BUCKET;           // your S3 bucket
const DDB_TABLE      = "Tasks";                         // your DynamoDB table name
const SNS_TOPIC_ARN  = process.env.SNS_TOPIC_ARN;

const RDS_TABLE      = process.env.DB_TASK;             // e.g. "tasks"
const RDS_SCHEMA     = process.env.DB_SCHEMA_TASK;      // e.g. "tasks_data"
const FULL_RDS_TABLE = `${RDS_SCHEMA}.${RDS_TABLE}`;

const CORS_HEADERS = {
  'Access-Control-Allow-Origin':  '*',
  'Access-Control-Allow-Methods': 'OPTIONS,POST,PUT',
  'Access-Control-Allow-Headers': 'Content-Type'
};

exports.handler = async (event) => {
  // 1) CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: CORS_HEADERS, body: '' };
  }

  // 2) Grab taskId from path
  const taskId = event.pathParameters?.id;
  if (!taskId) {
    return {
      statusCode: 400,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: 'Missing taskId in path' })
    };
  }

  // 3) Parse incoming payload (supports JSON or multipart)
  let fields = {}, files = [];
  const contentType = (event.headers['Content-Type'] || event.headers['content-type'] || '').toLowerCase();

  if (contentType.startsWith('multipart/form-data')) {
    // form-data (files + fields)
    const parsed = await parser.parse(event);
    fields = parsed.fields;
    files  = parsed.files;
  } else if (contentType.includes('application/json')) {
    // pure JSON
    fields = JSON.parse(event.body || '{}');
  } else {
    return {
      statusCode: 415,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: `Unsupported Content-Type: ${contentType}` })
    };
  }

  try {
    // 4) Get existing row (to pull attachments & cognito_sub)
    const pgRes = await pool.query(
      `SELECT attachments, cognito_sub
         FROM ${FULL_RDS_TABLE}
        WHERE task_id = $1`,
      [taskId]
    );
    if (!pgRes.rows || pgRes.rows.length === 0) {
      return {
        statusCode: 404,
        headers: CORS_HEADERS,
        body: JSON.stringify({ error: 'Task not found' })
      };
    }
    const row = pgRes.rows[0];
    const existingAttachments = Array.isArray(row.attachments) ? row.attachments : [];
    const cognito_sub = row.cognito_sub;

    // 5) Upload any new files to S3
    let newUrls = [];
    if (files.length) {
      newUrls = await Promise.all(files.map(async file => {
        const key = `tasks/${Date.now()}_${file.filename}`;
        await s3.putObject({
          Bucket:      BUCKET,
          Key:         key,
          Body:        file.content,
          ContentType: file.contentType
        }).promise();
        return `https://${BUCKET}.s3.amazonaws.com/${key}`;
      }));
    }

    // 6) Merge attachments into the update payload
    const updates = { ...fields };
    if (newUrls.length) {
      updates.attachments = [...existingAttachments, ...newUrls];
    }

    // 7) Build dynamic partial‐update
    const updateKeys = Object.keys(updates);
    if (updateKeys.length === 0) {
      return {
        statusCode: 400,
        headers: CORS_HEADERS,
        body: JSON.stringify({ error: 'No updatable fields provided' })
      };
    }

    // Helper: map camelCase dueDate → snake_case due_date
    const toColumn = col => col === 'dueDate' ? 'due_date' : col;

    const setClause = updateKeys
      .map((col, i) => `${toColumn(col)} = $${i + 1}`)
      .join(', ');
    const values = updateKeys.map(k => updates[k]);
    values.push(taskId);

    await pool.query(
      `UPDATE ${FULL_RDS_TABLE}
         SET ${setClause}
       WHERE task_id = $${values.length}`,
      values
    );

    // 8) Fetch previous DynamoDB item (so we can include it in the notification)
    const prevDdb = await dynamoDB.send(new GetCommand({
      TableName: DDB_TABLE,
      Key:       { taskId }
    }));
    const prevItem = prevDdb.Item || {};

    // 9) Update DynamoDB metadata + any changed fields
    const now = new Date().toISOString();
    const exprNames  = { '#updatedAt': 'updatedAt' };
    const exprValues = { ':updatedAt': now };
    const setParts   = ['#updatedAt = :updatedAt'];

    updateKeys.forEach(key => {
      exprNames[`#${key}`]  = key;
      exprValues[`:${key}`] = updates[key];
      setParts.push(`#${key} = :${key}`);
    });

    const { Attributes: newItem } = await dynamoDB.send(new UpdateCommand({
      TableName:                DDB_TABLE,
      Key:                      { taskId },
      UpdateExpression:         'SET ' + setParts.join(', '),
      ExpressionAttributeNames: exprNames,
      ExpressionAttributeValues:exprValues,
      ReturnValues:             'ALL_NEW'
    }));

    // 10) Lookup the user’s email for SNS
    const userRes = await pool.query(
      `SELECT email FROM users_data.users WHERE cognito_sub = $1`,
      [cognito_sub]
    );
    const email = userRes.rows[0]?.email || null;

    // 11) Publish an SNS notification
    await snsClient.send(new PublishCommand({
      TopicArn: SNS_TOPIC_ARN,
      Message: JSON.stringify({
        action:        'task updated',
        taskId,
        email,
        timestamp:     now,
        previousItem:  prevItem,
        updatedFields: updates,
        newItem
      })
    }));

    // 12) Return success (including the final attachments array)
    return {
      statusCode: 200,
      headers: {
        ...CORS_HEADERS,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        message:     'Task updated',
        attachments: updates.attachments ?? existingAttachments
      })
    };

  } catch (err) {
    console.error('updateTask error:', err);
    return {
      statusCode: 500,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: err.message })
    };
  }
};
