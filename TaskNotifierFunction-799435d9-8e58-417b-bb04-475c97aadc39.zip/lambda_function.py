import os, json, boto3

ses = boto3.client('ses', region_name=os.environ.get('AWS_REGION'))

def lambda_handler(event, context):
    for record in event['Records']:
        p = json.loads(record['body'])
        to     = p.get('email')
        tid    = p['taskId']
        action = p['action']
        print(f"📨 Received notification for task #{tid} {action}")
        # print(to) 
        if not to:
            print(f"⚠️ No email in message, skipping: {p}")
            continue

        subject = f"Task #{tid} {action}"
        body    = (
            f"<p>Your task <b>#{tid}</b> was <b>{action}</b>.</p>"
            "<p>WE DESERVE AN A+ TBH :)</p>"
        )
        print(f"📨 Sending notification to {to}")

        ses.send_email(
            Source      = "ahmed.hegab@student.giu-uni.de",
            Destination = {"ToAddresses": [to]},
            Message     = {
                "Subject": {"Data": subject},
                "Body":    {"Html": {"Data": body}}
            }
        )
        print(f"📧 Sent notification to {to}")

    return {"statusCode": 200}
