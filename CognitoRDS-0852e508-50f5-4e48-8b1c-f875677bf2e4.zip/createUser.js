const { Pool } = require('pg');

const pool = new Pool({
  host: process.env.DB_HOST,
  port: Number(process.env.DB_PORT),
  user: process.env.DB_USERNAME,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME || 'TaskManagerRDS_DB',
  ssl: { rejectUnauthorized: false },
});

exports.handler = async (event) => {
  try {
    const { sub, email, name } = event.request.userAttributes;

    console.log("✅ PostConfirmation event:", JSON.stringify(event, null, 2));

    const client = await pool.connect();
    await client.query(`
      INSERT INTO users_data.users (cognito_sub, email, username)
      VALUES ($1, $2, $3)
      ON CONFLICT (email)
      DO UPDATE SET
        cognito_sub = EXCLUDED.cognito_sub,
        username = EXCLUDED.username,
        created_at = CURRENT_TIMESTAMP
    `, [sub, email, name || 'NoName']);
    client.release();

    // ✅ Return the same event object (required by Cognito)
    return event;

  } catch (err) {
    console.error("❌ Error in PostConfirmation Lambda:", err);
    throw err;  // Failing here stops the confirmation process
  }
};
