require('dotenv').config();
const AWS                      = require('aws-sdk');
const { pool }                 = require('./db/rds-config');
const { dynamoDB, GetCommand } = require('./db/aws-config');

const DDB_TABLE  = process.env.DYNAMODB_TASK_TABLE || 'Tasks';
const RDS_SCHEMA = process.env.DB_SCHEMA_TASK;   // e.g. "tasks_data"
const RDS_TABLE  = process.env.DB_TASK;          // e.g. "tasks"
const FULL_RDS   = `${RDS_SCHEMA}.${RDS_TABLE}`;

// 🎯 Whitelist your front-end origins here:
const ALLOWED_ORIGINS = [
  'http://localhost:3000'
];

module.exports.handler = async (event) => {
  // ─── CORS SETUP ─────────────────────────────────────────────────────────────
  const origin = event.headers.origin || event.headers.Origin || '';
  const allowedOrigin = ALLOWED_ORIGINS.includes(origin)
    ? origin
    : ALLOWED_ORIGINS[0];

  const corsHeaders = {
    'Access-Control-Allow-Origin':      allowedOrigin,
    'Access-Control-Allow-Credentials': 'true',
    'Access-Control-Allow-Headers':     'Content-Type,Authorization',
    'Access-Control-Allow-Methods':     'GET,OPTIONS'
  };

  // Preflight handler
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 204,
      headers: corsHeaders,
      body: ''
    };
  }

  try {
    // ── 0) Grab the raw Authorization header ───────────────────────────────────
    const authHeader =
      event.headers?.authorization ||
      event.headers?.Authorization;

    if (!authHeader || !authHeader.match(/^Bearer /i)) {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ error: 'Unauthorized – no Bearer token' })
      };
    }

    // ── 1) Decode the JWT payload to pull out `sub` ────────────────────────────
    const token = authHeader.replace(/^Bearer\s+/i, '');
    const parts = token.split('.');
    if (parts.length !== 3) {
      throw new Error('Invalid JWT format');
    }
    const payloadJson = Buffer.from(parts[1], 'base64').toString('utf8');
    const claims      = JSON.parse(payloadJson);
    const userId      = claims.sub;
    if (!userId) {
      return {
        statusCode: 401,
        headers: corsHeaders,
        body: JSON.stringify({ error: 'Unauthorized – no sub in token' })
      };
    }

    // ── 2) Fetch only this user’s tasks from Postgres ───────────────────────────
    const { rows } = await pool.query(
      `
        SELECT
          task_id       AS "taskId",
          title,
          description,
          status,
          attachments,
          priority
        FROM ${FULL_RDS}
        WHERE cognito_sub = $1
      `,
      [userId]
    );

    // ── 3) Enrich each task with DynamoDB metadata ─────────────────────────────
    const tasksWithMeta = await Promise.all(
      rows.map(async (task) => {
        const metaResp = await dynamoDB.send(
          new GetCommand({
            TableName: DDB_TABLE,
            Key:       { taskId: task.taskId }
          })
        );
        return {
          ...task,
          metadata: metaResp.Item || {}
        };
      })
    );

    // ── 4) Return an array (even if empty) ────────────────────────────────────
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify(tasksWithMeta)
    };

  } catch (error) {
    console.error('getTasks error:', error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: error.message })
    };
  }
};
